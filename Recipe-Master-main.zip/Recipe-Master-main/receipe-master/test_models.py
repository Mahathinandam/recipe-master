# import google.generativeai as genai
# import os

# genai.configure(api_key="AIzaSyAunAnNYpi-Dy3gyAAO-7Um6Dv3cGjFOg4")

# models = genai.list_models()
# for m in models:
#     print(m.name, m.supported_generation_methods)
